@extends('layouts.master')

@section('content')
{{-- <div class="nd_tds_display_none_responsive nd_tds_right_30 nd_tds_bottom_30 nd_tds_position_fixed nd_tds_z_index_99">
    <span style="top:1px; left:5px; font-size:8px; line-height:10px; border-radius:0px; padding:3px 5px;" class="nd_tds_position_absolute nd_tds_color_fff_important nd_tds_background_color_3">BUY NOW</span>    
    <a href="javascript:;" target="_blank" class="nd_tds_text_align_center nd_tds_width_65 nd_tds_float_left nd_tds_height_65 nd_tds_display_table nd_tds_font_size_25 nd_tds_line_height_25 nd_tds_color_fff_important nd_tds_border_radius_100_percentage nd_tds_background_color_1 nd_tds_box_shadow_0_0_20_000_015 nd_options_second_font">
        <span class="nd_tds_position_absolute nd_tds_top_22 nd_tds_left_13 nd_tds_font_size_8 nd_tds_line_height_8">$</span>    
        <span style="padding-top:7px;" class="nd_tds_display_table_cell nd_tds_vertical_align_middle nd_tds_padding_left_5">54</span>
    </a>
</div>
<div style="right:80px;" class="nd_tds_display_none_responsive nd_tds_bottom_30 nd_tds_position_fixed nd_tds_z_index_99">
    <a target="_blank" class="nd_tds_border_radius_100_percentage nd_tds_width_35 nd_tds_height_35 nd_tds_float_left nd_tds_background_color_2 nd_tds_box_shadow_0_0_20_000_015" href="https://1.envato.market/PZ42q">
    <img class="nd_tds_position_absolute nd_tds_left_10 nd_tds_top_10" width="15px" src="./About Us – Travel WordPress Theme_files/envato.png">
    </a>
</div> --}}
<div id="nd_options_page_header_img_layout_5" class="nd_options_section nd_options_background_size_cover nd_options_background_position_center_bottom" style="background-image:url(assets/images/about/p-16.jpg);">
    <div class="nd_options_section nd_options_bg_greydark_alpha_3">
        <!--start nd_options_container-->
        <div class="nd_options_container nd_options_clearfix">
            <div id="nd_options_page_header_image_space_top" class="nd_options_section nd_options_height_110"></div>
            <div class="nd_options_section nd_options_padding_15 nd_options_box_sizing_border_box nd_options_text_align_center">
                <h1 class="nd_options_color_white nd_options_font_weight_normal nd_options_first_font">
                    <span class="nd_options_display_block">ABOUT US</span>
                    <div class="nd_options_section"><span class="nd_options_bg_white nd_options_width_80 nd_options_height_4 nd_options_display_inline_block"></span></div>
                </h1>
            </div>
            <div id="nd_options_page_header_image_space_bottom" class="nd_options_section nd_options_height_110"></div>
        </div>
        <!--end container-->
    </div>
</div>
<!--page margin-->
<div class="nd_options_section nd_options_height_50"></div>
<!--start nd_options_container-->
<div class="nd_options_container nd_options_padding_0_15 nd_options_box_sizing_border_box nd_options_clearfix">
    <!--#post-->
    <div style="float:left; width:100%;" id="post-206" class="post-206 page type-page status-publish hentry">
        <!--automatic title-->
        <!--start content-->
        <div class="vc_row wpb_row vc_row-fluid">
            <div class="wpb_column vc_column_container vc_col-sm-12">
                <div class="vc_column-inner vc_custom_1467360650255">
                    <div class="wpb_wrapper">
                        <div style="background-color:; height: 10px;" class="nicdark_section  "></div>
                        <h1 style="color:; padding:px; text-align:center; font-size:40px; line-height:50px; letter-spacing: px; font-weight:normal;" class="  nd_options_text_align_center_responsive_important nd_options_first_font ">All at your convenience and affordable prices with Halesi Travels and Tours.</h1>
                    </div>
                </div>
            </div>
            <div class="wpb_column vc_column_container vc_col-sm-4">
                <div class="vc_column-inner vc_custom_1467207292391">
                    <div class="wpb_wrapper">
                        <div style="background-color:; height: 20px;" class="nicdark_section  "></div>
                        <div class="wpb_text_column wpb_content_element  nd_options_text_align_center_responsive">
                            <div class="wpb_wrapper">
                                <p>Relax and gather the energy pack for the forthcoming works with a Comfortable journey that fulfills the purpose of your tour. </p>
                            </div>
                        </div>
                        <div style="background-color:; height: 20px;" class="nicdark_section  "></div>
                        <div class="wpb_text_column wpb_content_element  nd_options_text_align_center_responsive">
                            <div class="wpb_wrapper">
                                <p>You feel that it's a piece of cake for you to travel to the wonders of the world.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="wpb_column vc_column_container vc_col-sm-4">
                <div class="vc_column-inner vc_custom_1467207298589">
                    <div class="wpb_wrapper">
                        <div style="background-color:; height: 20px;" class="nicdark_section  "></div>
                        <div class="wpb_text_column wpb_content_element  nd_options_text_align_center_responsive">
                            <div class="wpb_wrapper">
                                <p>Feel the art works at every step you take on the Delhi tour. Marble works of love, red brick of blood and sweat in history, Artworks from skilled hands and much more that longs for your presence.</p>
                            </div>
                        </div>
                        <div style="background-color:; height: 20px;" class="nicdark_section  "></div>
                        <div class="wpb_text_column wpb_content_element  nd_options_text_align_center_responsive">
                            <div class="wpb_wrapper">
                                <p>Make incredible moments with monuments you should visit at least once in your lifetime and learn historical facts that many books don't teach you.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="wpb_column vc_column_container vc_col-sm-4">
                <div class="vc_column-inner vc_custom_1467207292391">
                    <div class="wpb_wrapper">
                        <div style="background-color:; height: 20px;" class="nicdark_section  "></div>
                        <div class="wpb_text_column wpb_content_element  nd_options_text_align_center_responsive">
                            <div class="wpb_wrapper">
                                <p>Fly so high to visit your dream places while the gentle breeze comforts you and soul stirring background music smoothes your journey.</p>
                            </div>
                        </div>
                        <div style="background-color:; height: 20px;" class="nicdark_section  "></div>
                        <div class="wpb_text_column wpb_content_element  nd_options_text_align_center_responsive">
                            <div class="wpb_wrapper">
                                <p>Read less reviews to experience the real adventure that awaits you to chill and thrill you at every spot you visit.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="vc_row wpb_row vc_row-fluid vc_custom_1492510780167">
            <div class="wpb_column vc_column_container vc_col-sm-4">
                <div class="vc_column-inner ">
                    <div class="wpb_wrapper">
                        <div style="background-color:; height: 10px;" class="nicdark_section  "></div>
                        <!--START team-->
                        <div class="nd_options_section nd_options_box_sizing_border_box nd_options_about_us_team ">
                            <div class="nd_options_section nd_options_position_relative">
                                <img alt="" class="nd_options_section" src="{{ asset('assets/images/about/sqb-2.jpg') }}">
                                <div class="nd_options_bg_greydark_alpha_gradient_3 nd_options_position_absolute nd_options_left_0 nd_options_height_100_percentage nd_options_width_100_percentage nd_options_box_sizing_border_box">
                                    <div class="nd_options_position_absolute nd_options_bottom_30 nd_options_width_100_percentage nd_options_padding_botttom_0 nd_options_padding_50 nd_options_box_sizing_border_box nd_options_text_align_center">
                                        <h3 class="nd_options_color_white">CITY TOURS</h3>
                                        <div class="nd_options_section nd_options_height_10"></div>
                                        <h6 class="nd_options_color_white"><strong>CULTURAL AND ARTS</strong></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--END team-->
                        <div style="background-color:; height: 10px;" class="nicdark_section  "></div>
                    </div>
                </div>
            </div>
            <div class="wpb_column vc_column_container vc_col-sm-4">
                <div class="vc_column-inner ">
                    <div class="wpb_wrapper">
                        <div style="background-color:; height: 10px;" class="nicdark_section  "></div>
                        <!--START team-->
                        <div class="nd_options_section nd_options_box_sizing_border_box nd_options_about_us_team ">
                            <div class="nd_options_section nd_options_position_relative">
                                <img alt="" class="nd_options_section" src="{{ asset('assets/images/about/sqb-3.jpg') }}">
                                <div class="nd_options_bg_greydark_alpha_gradient_3 nd_options_position_absolute nd_options_left_0 nd_options_height_100_percentage nd_options_width_100_percentage nd_options_box_sizing_border_box">
                                    <div class="nd_options_position_absolute nd_options_bottom_30 nd_options_width_100_percentage nd_options_padding_botttom_0 nd_options_padding_50 nd_options_box_sizing_border_box nd_options_text_align_center">
                                        <h3 class="nd_options_color_white">HONEYMOON</h3>
                                        <div class="nd_options_section nd_options_height_10"></div>
                                        <h6 class="nd_options_color_white"><strong>LUXURY RESORTS</strong></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--END team-->
                        <div style="background-color:; height: 10px;" class="nicdark_section  "></div>
                    </div>
                </div>
            </div>
            <div class="wpb_column vc_column_container vc_col-sm-4">
                <div class="vc_column-inner ">
                    <div class="wpb_wrapper">
                        <div style="background-color:; height: 10px;" class="nicdark_section  "></div>
                        <!--START team-->
                        <div class="nd_options_section nd_options_box_sizing_border_box nd_options_about_us_team ">
                            <div class="nd_options_section nd_options_position_relative">
                                <img alt="" class="nd_options_section" src="{{ asset('assets/images/about/sqb-1.jpg') }}">
                                <div class="nd_options_bg_greydark_alpha_gradient_3 nd_options_position_absolute nd_options_left_0 nd_options_height_100_percentage nd_options_width_100_percentage nd_options_box_sizing_border_box">
                                    <div class="nd_options_position_absolute nd_options_bottom_30 nd_options_width_100_percentage nd_options_padding_botttom_0 nd_options_padding_50 nd_options_box_sizing_border_box nd_options_text_align_center">
                                        <h3 class="nd_options_color_white">ADVENTURE</h3>
                                        <div class="nd_options_section nd_options_height_10"></div>
                                        <h6 class="nd_options_color_white"><strong>COOL EXPERIENCES</strong></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--END team-->
                        <div style="background-color:; height: 10px;" class="nicdark_section  "></div>
                    </div>
                </div>
            </div>
        </div>
        <div data-vc-full-width="true" data-vc-full-width-init="true" data-vc-parallax="1.5" data-vc-parallax-image="{{ asset('assets/images/about/p-9.jpg') }}" class="vc_row wpb_row vc_row-fluid nd_options_vc_parallax_filter_2_2 vc_custom_1524240780760 vc_row-has-fill vc_general vc_parallax vc_parallax-content-moving" style="position: relative; left: -71.5px; box-sizing: border-box; width: 1343px; padding-left: 71.5px; padding-right: 71.5px;">
            <div class="wpb_column vc_column_container vc_col-sm-8">
                <div class="vc_column-inner ">
                    <div class="wpb_wrapper">
                        <div class="nd_options_section nd_options_position_relative nd_options_about_us_service">
                            <div class="nd_options_section nd_options_padding_left_80 nd_options_box_sizing_border_box">
                                <h1 class="nd_options_font_size_40 nd_options_line_height_50" style="color:#ffffff;"><strong>Doing the right thing,<br>
                                    at the right time.</strong>
                                </h1>
                            </div>
                        </div>
                        <div style="background-color:; height: 70px;" class="nicdark_section  "></div>
                        <div class="vc_row wpb_row vc_inner vc_row-fluid">
                            <div class="wpb_column vc_column_container vc_col-sm-3">
                                <div class="vc_column-inner vc_custom_1469630269458">
                                    <div class="wpb_wrapper">
                                        <script type="text/javascript">
                                            //<![CDATA[
                                            
                                            jQuery(document).ready(function() {
                                            
                                              //START counter
                                              jQuery(function ($) {
                                                
                                                // start all the timers
                                                $(".nd_options_counter").each(count);
                                                
                                                function count(options) {
                                                    var $this = $(this);
                                                    options = $.extend({}, options || {}, $this.data("countToOptions") || {});
                                                    $this.countTo(options);
                                                }
                                            
                                              });
                                              //END counter
                                            
                                            });
                                            
                                            //]]&gt;
                                        </script>
                                        <h1 style="text-align:center; color:#ffffff; font-size:50px; " class=" nd_options_font_weight_bolder nd_options_counter nd_options_about_us_counter " data-to="15" data-speed="1000">15</h1>
                                        <div style="background-color:; height: 20px;" class="nicdark_section  "></div>
                                        <p style="color:#ffffff; padding:px; text-align:center; font-size:15px; line-height:30px; letter-spacing: 1px; font-weight:normal;" class="   nd_options_second_font ">BRANCHES</p>
                                    </div>
                                </div>
                            </div>
                            <div class="wpb_column vc_column_container vc_col-sm-3">
                                <div class="vc_column-inner vc_custom_1469630276028">
                                    <div class="wpb_wrapper">
                                        <script type="text/javascript">
                                            //<![CDATA[
                                            
                                            jQuery(document).ready(function() {
                                            
                                              //START counter
                                              jQuery(function ($) {
                                                
                                                // start all the timers
                                                $(".nd_options_counter").each(count);
                                                
                                                function count(options) {
                                                    var $this = $(this);
                                                    options = $.extend({}, options || {}, $this.data("countToOptions") || {});
                                                    $this.countTo(options);
                                                }
                                            
                                              });
                                              //END counter
                                            
                                            });
                                            
                                            //]]&gt;
                                        </script>
                                        <h1 style="text-align:center; color:#ffffff; font-size:50px; " class=" nd_options_font_weight_bolder nd_options_counter nd_options_about_us_counter " data-to="100" data-speed="1000">100</h1>
                                        <div style="background-color:; height: 20px;" class="nicdark_section  "></div>
                                        <p style="color:#ffffff; padding:px; text-align:center; font-size:15px; line-height:30px; letter-spacing: 1px; font-weight:normal;" class="   nd_options_second_font ">TOURS</p>
                                    </div>
                                </div>
                            </div>
                            <div class="wpb_column vc_column_container vc_col-sm-3">
                                <div class="vc_column-inner vc_custom_1469630283566">
                                    <div class="wpb_wrapper">
                                        <script type="text/javascript">
                                            //<![CDATA[
                                            
                                            jQuery(document).ready(function() {
                                            
                                              //START counter
                                              jQuery(function ($) {
                                                
                                                // start all the timers
                                                $(".nd_options_counter").each(count);
                                                
                                                function count(options) {
                                                    var $this = $(this);
                                                    options = $.extend({}, options || {}, $this.data("countToOptions") || {});
                                                    $this.countTo(options);
                                                }
                                            
                                              });
                                              //END counter
                                            
                                            });
                                            
                                            //]]&gt;
                                        </script>
                                        <h1 style="text-align:center; color:#ffffff; font-size:50px; " class=" nd_options_font_weight_bolder nd_options_counter nd_options_about_us_counter " data-to="47" data-speed="1000">47</h1>
                                        <div style="background-color:; height: 20px;" class="nicdark_section  "></div>
                                        <p style="color:#ffffff; padding:px; text-align:center; font-size:15px; line-height:30px; letter-spacing: 1px; font-weight:normal;" class="   nd_options_second_font ">DESTINATIONS</p>
                                    </div>
                                </div>
                            </div>
                            <div class="wpb_column vc_column_container vc_col-sm-3">
                                <div class="vc_column-inner vc_custom_1469630289168">
                                    <div class="wpb_wrapper">
                                        <script type="text/javascript">
                                            //<![CDATA[
                                            
                                            jQuery(document).ready(function() {
                                            
                                              //START counter
                                              jQuery(function ($) {
                                                
                                                // start all the timers
                                                $(".nd_options_counter").each(count);
                                                
                                                function count(options) {
                                                    var $this = $(this);
                                                    options = $.extend({}, options || {}, $this.data("countToOptions") || {});
                                                    $this.countTo(options);
                                                }
                                            
                                              });
                                              //END counter
                                            
                                            });
                                            
                                            //]]&gt;
                                        </script>
                                        <h1 style="text-align:center; color:#ffffff; font-size:50px; " class=" nd_options_font_weight_bolder nd_options_counter nd_options_about_us_counter " data-to="10" data-speed="1000">10</h1>
                                        <div style="background-color:; height: 20px;" class="nicdark_section  "></div>
                                        <p style="color:#ffffff; padding:px; text-align:center; font-size:15px; line-height:30px; letter-spacing: 1px; font-weight:normal;" class="   nd_options_second_font ">STAFF</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="wpb_column vc_column_container vc_col-sm-4">
                <div class="vc_column-inner ">
                    <div class="wpb_wrapper"></div>
                </div>
            </div>
            <div class="vc_parallax-inner skrollable skrollable-before" data-bottom-top="top: -50%;" data-top-bottom="top: 0%;" style="height: 150%; background-image: url(&quot;assets/images/about/p-9.jpg&quot;); top: -50%;"></div>
        </div>
        <div class="vc_row-full-width vc_clearfix"></div>
        <?php /*<div class="vc_row wpb_row vc_row-fluid vc_custom_1492509935473">
            <div class="nd_options_text_align_center wpb_column vc_column_container vc_col-sm-1">
                <div class="vc_column-inner ">
                    <div class="wpb_wrapper"></div>
                </div>
            </div>
            <div class="wpb_column vc_column_container vc_col-sm-5">
                <div class="vc_column-inner ">
                    <div class="wpb_wrapper">
                        <div style="background-color:; height: 25px;" class="nicdark_section  "></div>
                        <div class="nd_options_section nd_options_position_relative ">
                            <img style="top:10px;" alt="" class="nd_options_position_absolute nd_options_left_0" width="50" src="{{ asset('assets/images/about/icon-boat.png') }}">
                            <div style="padding-left:70px;" class="nd_options_section nd_options_box_sizing_border_box">
                                <p class="nd_options_second_font  " style="margin:0px 0px 15px 0px; color:#878787; font-size:14px;line-height:24px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue ipsum dolor.</p>
                                <a class="nd_options_second_font nd_options_display_inline_block " style="font-size:11px; line-height:11px; border-radius:0px; border:0px solid #ffffff; background-color:#ba71da; padding:8px 12px; color:#ffffff;" rel="" href="javascript:;">CRUISES</a>
                            </div>
                        </div>
                        <div style="background-color:; height: 50px;" class="nicdark_section  "></div>
                        <div class="nd_options_section nd_options_position_relative ">
                            <img style="top:10px;" alt="" class="nd_options_position_absolute nd_options_left_0" width="50" src="{{ asset('assets/images/about/icon-island.png') }}">
                            <div style="padding-left:70px;" class="nd_options_section nd_options_box_sizing_border_box">
                                <p class="nd_options_second_font  " style="margin:0px 0px 15px 0px; color:#878787; font-size:14px;line-height:24px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue ipsum dolor.</p>
                                <a class="nd_options_second_font nd_options_display_inline_block " style="font-size:11px; line-height:11px; border-radius:0px; border:0px solid #ffffff; background-color:#f76570; padding:8px 12px; color:#ffffff;" rel="" href="javascript:;">RESORTS</a>
                            </div>
                        </div>
                        <div style="background-color:; height: 25px;" class="nicdark_section  "></div>
                    </div>
                </div>
            </div>
            <div class="wpb_column vc_column_container vc_col-sm-5">
                <div class="vc_column-inner ">
                    <div class="wpb_wrapper">
                        <div style="background-color:; height: 25px;" class="nicdark_section  "></div>
                        <div class="nd_options_section nd_options_position_relative ">
                            <img style="top:10px;" alt="" class="nd_options_position_absolute nd_options_left_0" width="50" src="{{ asset('assets/images/about/icon-landmark.png') }}">
                            <div style="padding-left:70px;" class="nd_options_section nd_options_box_sizing_border_box">
                                <p class="nd_options_second_font  " style="margin:0px 0px 15px 0px; color:#878787; font-size:14px;line-height:24px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue ipsum dolor.</p>
                                <a class="nd_options_second_font nd_options_display_inline_block " style="font-size:11px; line-height:11px; border-radius:0px; border:0px solid #ffffff; background-color:#14b9d5; padding:8px 12px; color:#ffffff;" rel="" href="javascript:;">BEST TOURS</a>
                            </div>
                        </div>
                        <div style="background-color:; height: 50px;" class="nicdark_section  "></div>
                        <div class="nd_options_section nd_options_position_relative ">
                            <img style="top:10px;" alt="" class="nd_options_position_absolute nd_options_left_0" width="50" src="{{ asset('assets/images/about/icon-map.png') }}">
                            <div style="padding-left:70px;" class="nd_options_section nd_options_box_sizing_border_box">
                                <p class="nd_options_second_font  " style="margin:0px 0px 15px 0px; color:#878787; font-size:14px;line-height:24px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue ipsum dolor.</p>
                                <a class="nd_options_second_font nd_options_display_inline_block " style="font-size:11px; line-height:11px; border-radius:0px; border:0px solid #ffffff; background-color:#1bbc9b; padding:8px 12px; color:#ffffff;" rel="" href="javascript:;">MAP GUIDES</a>
                            </div>
                        </div>
                        <div style="background-color:; height: 25px;" class="nicdark_section  "></div>
                    </div>
                </div>
            </div>
            <div class="wpb_column vc_column_container vc_col-sm-1">
                <div class="vc_column-inner ">
                    <div class="wpb_wrapper"></div>
                </div>
            </div>
        </div>
        <div class="vc_row wpb_row vc_row-fluid vc_custom_1492511016596">
            <div class="nd_options_text_align_center wpb_column vc_column_container vc_col-sm-12">
                <div class="vc_column-inner ">
                    <div class="wpb_wrapper">
                        <div class="nd_options_section nd_options_text_align_center">
                            <a style="border: px solid ; border-radius:px; letter-spacing:1px; line-height:14px; font-size:14px; background-color:#434a54; padding:15px 25px; margin:; color:#ffffff;" rel="" href="javascript:;" class="nicdark_display_inline_block  nd_options_font_weight_normal nd_options_second_font  ">CHECK ALL SERVICES</a>
                        </div>
                    </div>
                </div>
            </div>
        </div> */ ?>
        <!--end content-->
    </div>
    <!--#post-->
</div>
<!--end container-->
@endsection