<!--START footer-->
<div style="background-color:#434a54; border-top: 1px solid #f1f1f1;  " id="nd_options_footer_4" class="nd_options_section">
    <div class="nd_options_section nd_options_height_50"></div>
    <!--start nd_options_container-->
    <div class="nd_options_container nd_options_clearfix">
        <div class="grid nd_options_grid_12 wpb_widgetised_column">
            <div id="text-2" class="widget widget_text">
                <div class="textwidget">
                    <div data-vc-full-width="true" data-vc-full-width-init="true" class="vc_row wpb_row vc_row-fluid" style="position: relative; left: -71.5px; box-sizing: border-box; width: 1343px; padding-left: 71.5px; padding-right: 71.5px;">
                        <div class="wpb_column vc_column_container vc_col-sm-4">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <h3 style="color:#ffffff; padding:px; text-align:; font-size:20px; line-height:20px; letter-spacing: px; font-weight:normal;" class="   nd_options_first_font ">Address:</h3>
                                    <div style="background-color:; height: 10px;" class="nicdark_section  "></div>
                                    <p style="color:#a3a3a4; padding:px; text-align:; font-size:12px; line-height:12px; letter-spacing: px; font-weight:;" class="   nd_options_second_font ">9A, Channa Market, <br /> Block 9A, WEA, <br /> Karol Bagh, <br /> New Delhi - 110005</p>
                                    <div style="background-color:; height: 28px;" class="nicdark_section  "></div>
                                    <p style="color:#ffffff; padding:px; text-align:; font-size:20px; line-height:20px; letter-spacing: 1px; font-weight:;" class="  nd_options_margin_bottom_50_responsive nd_options_second_font "><a href="tel:+911141003804">+91 11 4100 3804</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-4">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <h3 style="color:#ffffff; padding:px; text-align:; font-size:20px; line-height:20px; letter-spacing: px; font-weight:normal;" class="   nd_options_first_font ">Connect With Us</h3>
                                    <div style="background-color:; height: 10px;" class="nicdark_section  "></div>
                                    <p style="color:#a3a3a4; padding:px; text-align:; font-size:12px; line-height:12px; letter-spacing: px; font-weight:;" class="   nd_options_second_font ">SOCIAL MEDIA CHANNELS</p>
                                    <div style="background-color:; height: 30px;" class="nicdark_section  "></div>
                                    <a style="margin:0px 20px 0px 0px; border: px solid ; border-radius:px; background-color:; padding:; " rel="" href="javascript:;" class="nicdark_display_inline_block nd_options_float_left  "><img class="nd_options_float_left" alt="" width="20" src="{{ asset('assets/images/icon-instagram.png') }}"></a>
                                    <a style="margin:0px 20px 0px 0px; border: px solid ; border-radius:px; background-color:; padding:; " rel="" href="javascript:;" class="nicdark_display_inline_block nd_options_float_left  "><img class="nd_options_float_left" alt="" width="20" src="{{ asset('assets/images/icon-twitter.png') }}"></a>
                                    <a style="margin:0px 20px 0px 0px; border: px solid ; border-radius:px; background-color:; padding:; " rel="" href="javascript:;" class="nicdark_display_inline_block nd_options_float_left  "><img class="nd_options_float_left" alt="" width="20" src="{{ asset('assets/images/icon-facebook.png') }}"></a>
                                    <a style="margin:0px 20px 0px 0px; border: px solid ; border-radius:px; background-color:; padding:; " rel="" href="javascript:;" class="nicdark_display_inline_block nd_options_float_left  "><img class="nd_options_float_left" alt="" width="20" src="{{ asset('assets/images/icon-pinterest.png') }}"></a>
                                    <a style="margin:0px 20px 0px 0px; border: px solid ; border-radius:px; background-color:; padding:; " rel="" href="javascript:;" class="nicdark_display_inline_block nd_options_float_left  "><img class="nd_options_float_left" alt="" width="20" src="{{ asset('assets/images/icon-youtube.png') }}"></a>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-4">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <h3 style="color:#ffffff; padding:px; text-align:; font-size:20px; line-height:20px; letter-spacing: px; font-weight:normal;" class="  nd_options_margin_top_50_responsive nd_options_first_font ">Important Links</h3>
                                    <div style="background-color:; height: 10px;" class="nicdark_section  "></div>
                                    {{-- <p style="color:#a3a3a4; padding:px; text-align:; font-size:12px; line-height:12px; letter-spacing: px; font-weight:;" class="   nd_options_second_font ">SIGN UP FOR SPECIAL OFFERS</p> --}}
                                    <div style="background-color:; height: 5px;" class="nicdark_section  "></div>
                                    <!--start form-->
                                    <div id="nd_options_shortcode_cf7_72" class="nd_options_section ">
                                        <div class="nd_options_section nd_options_box_sizing_border_box">
                                            <div class="nd_options_display_none_all_responsive">
                                                <div class="nd_options_display_table_cell">
                                                    <div class="menu-menu-1-container">
                                                        <ul id="menu-menu-2" class="menu">
                                                            <li class="menu-item" style="border: none; padding: 0px;"><a href="{{ route('aboutUs') }}" aria-current="page">About Us</a></li>
                                                            <li class="menu-item" style="border: none; padding: 0px;"><a href="{{ route('terms-of-services') }}/#contact-us" aria-current="page">Terms Of Services</a></li>
                                                            <li class="menu-item" style="border: none; padding: 0px;"><a href="{{ route('privacy-policy') }}" aria-current="page">Privacy Policies</a></li>
                                                            <li class="menu-item" style="border: none; padding: 0px;"><a href="{{ route('refund-policies') }}" aria-current="page">Refund Policies</a></li>
                                                            <li class="menu-item" style="border: none; padding: 0px;"><a href="{{ route('welcome') }}/#contact-us" aria-current="page">Contact Us</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="height: 10px;" class="nd_options_section"></div>
                                            {{-- <div role="form" class="wpcf7" id="wpcf7-f72-o2" lang="en-US" dir="ltr">
                                                <div class="screen-reader-response"></div>
                                                <form action="javascript:;wpcf7-f72-o2" method="post" class="wpcf7-form" novalidate="novalidate">
                                                    <div style="display: none;">
                                                        <input type="hidden" name="_wpcf7" value="72">
                                                        <input type="hidden" name="_wpcf7_version" value="5.1.3">
                                                        <input type="hidden" name="_wpcf7_locale" value="en_US">
                                                        <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f72-o2">
                                                        <input type="hidden" name="_wpcf7_container_post" value="0">
                                                    </div>
                                                    <p></p>
                                                    <div class="nd_options_float_left nd_options_box_sizing_border_box nd_options_width_100_percentage_all_iphone_important nd_options_padding_0_right_important_all_iphone nd_options_padding_0_left_important_all_iphone " style="padding: 0px 0px 0px 0px; width:60%;"><span class="wpcf7-form-control-wrap email"><input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email nd_options_width_100_percentage nd_options_line_height_21 nd_travel_bg_greydark_2_important nd_travel_border_width_0_important" aria-required="true" aria-invalid="false" placeholder="Email"></span></div>
                                                    <div class="nd_options_float_left nd_options_box_sizing_border_box nd_options_width_100_percentage_all_iphone_important nd_options_padding_0_right_important_all_iphone nd_options_padding_0_left_important_all_iphone " style="padding: 0px 0px 0px 0px; width:40%;"><input type="submit" value="SUBSCRIBE" class="wpcf7-form-control wpcf7-submit nd_travel_padding_15_30_important nd_options_second_font_important nd_options_color_white nd_travel_display_inline_block nd_travel_font_size_11 nd_travel_letter_spacing_2 nd_travel_section"><span class="ajax-loader"></span></div>
                                                    <p></p>
                                                    <div class="wpcf7-response-output wpcf7-display-none"></div>
                                                </form>
                                            </div> --}}
                                        </div>
                                    </div>
                                    <!--end form-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row-full-width vc_clearfix"></div>
                </div>
            </div>
        </div>
    </div>
    <!--end container-->
    <div class="nd_options_section nd_options_height_10"></div>
</div>
<!--END footer-->
<!--START copyright-->
<div style="background-color:#fff;" id="nd_options_footer_4_copyright" class="nd_options_section">
    <!--start nd_options_container-->
    <div style="border-top: 1px solid #f1f1f1 " class="nd_options_container nd_options_clearfix">
        <div class="grid nd_options_grid_6 nd_options_text_align_center_responsive">
            <p class="nd_options_font_size_14 nd_options_line_height_25_responsive">© Copyright {{ date('Y') }} Halesi Travels</p>
        </div>
        {{-- <div class="grid nd_options_grid_6 nd_options_text_align_right nd_options_text_align_center_responsive">
            <p class="nd_options_font_size_14 nd_options_line_height_25_responsive">Best Travel WordPress Theme</p>
        </div> --}}
    </div>
    <!--end container-->
</div>
<!--END copyright-->